
"""
This is the initialization file for the NLP module of the decentralized AI platform.
"""

from . import views
