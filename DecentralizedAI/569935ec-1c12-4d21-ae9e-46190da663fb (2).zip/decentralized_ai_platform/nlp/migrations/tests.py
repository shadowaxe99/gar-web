
import unittest
from django.test import TestCase
from nlp.models import NLPModel

class NLPModelTestCase(TestCase):
    def setUp(self):
        NLPModel.objects.create(name="Test NLP Model")

    def test_nlp_model_creation(self):
        """Models are being properly created"""
        model = NLPModel.objects.get(name="Test NLP Model")
        self.assertEqual(model.name, 'Test NLP Model')

if __name__ == '__main__':
    unittest.main()
