# __init__.py file for nlp migrations

# This file ensures that the migrations directory is treated as a Python package

# No code is required in this file. It's created to define the directory as a package.